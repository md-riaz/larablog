<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Artisan extends Controller
{
    public function migrate()
    {
        Artisan::call('migrate:fresh');
    }
}
