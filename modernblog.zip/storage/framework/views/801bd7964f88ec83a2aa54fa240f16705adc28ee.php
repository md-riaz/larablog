<!--   Feature Post Section -->
<section class="feature-posts d-none">
    <div class="feature-posts_wrapper d_flex feature-post-slider owl-carousel owl-theme">

        <?php $__empty_1 = true; $__currentLoopData = $feature_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <div class="feature-post d_flex item owl-lazy" data-src="<?php echo e(asset($item->post_img)); ?>">
                <span class="overlay"></span>
                <div class="feature-post_content d_flex">
                    <div class="categories d_flex">
                        <a href="<?php echo e(url('/categories/'.$item->category->slug)); ?>"><?php echo e($item->category->name); ?></a>
                    </div>
                    <a class="title" href="<?php echo e(url('post/'. $item->slug)); ?>">
                        <?php echo e($item->title); ?>

                    </a>
                    <div class="post_bottom d_flex">
                        <p class="date"><?php echo e($item->created_at->format('d F, Y')); ?></p>
                        <div class="comments d_flex">
                            <i class="fas fa-comment"></i>
                            <p> <?php echo e($item->comments_count); ?></p>
                        </div>
                    </div>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No Post to show</p>
        <?php endif; ?>
    </div>
    <div class="btn-prev"></div>
    <div class="btn-next"></div>
</section>
<!--   Feature Post Section End -->
<?php /**PATH D:\laragon\www\modernblog\resources\views/components/featured.blade.php ENDPATH**/ ?>