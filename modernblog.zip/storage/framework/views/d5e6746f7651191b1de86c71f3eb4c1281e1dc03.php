<?php $__env->startSection('title' ,'Admin Panel'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12 p-0">
        <h3>All Registered Users</h3>
        <div class="table-responsive text-nowrap">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>SL</th>
                    <th>User Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Posts</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($users->firstItem() + $loop->index); ?></td>
                        <td><a href="<?php echo e(route('users.show', $user->id)); ?>"><?php echo e($user->name); ?></a></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->role->name); ?></td>
                        <td><?php echo e($user->posts_count); ?></td>
                        <td>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user)): ?>
                                <a href="#" class="btn text-primary"><i
                                        class="far fa-edit"></i></a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $user)): ?>
                                <form action="" id="deleteForm" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn text-danger" id="delete"
                                            data-action="<?php echo e(route('users.destroy',$user->id)); ?>"><i
                                            class="fas fa-trash"></i></button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <td>No data available</td>
                <?php endif; ?>
                </tbody>
            </table>

            <!-- pagination -->
        <?php if($users->lastPage() > 1): ?>
            <?php echo e($users->links()); ?>

        <?php endif; ?>
        <!-- pagination End -->

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\modernblog\resources\views/users/index.blade.php ENDPATH**/ ?>