<!-- Site title -->
<?php $__env->startSection('title' ,'Write Post'); ?>
<!-- stylesheets -->
<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="col pb-5">
        <div class="write-post">
            <div>
                <h2>Write a new post here.</h2>
                <!--  Displaying The Validation Errors -->
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
            <?php endif; ?>
            <!-- Displaying The Validation Errors -->
                <div>
                    <form action="<?php echo e(route('post.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="d_flex justify-between">
                            <div class="input-field">
                                <label for="title">Title</label>
                                <input type="text" name="title" placeholder="Post Title *" aria-required="true" required
                                       id="title" max="255" value="<?php echo e(old('title')); ?>"/>
                            </div>
                            <div class="input-field">
                                <label for="category">Category</label>
                                <select name="category_id" id="category">
                                    <option value="" disabled selected>Select a Category</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($item->id); ?>" <?php echo e(old('category_id')==$item->id  ? 'selected' : ''); ?>>
                                            <?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="input-field">
                            <label for="slug">Slug</label>
                            <input type="text" name="slug" placeholder="Slug/url*" aria-required="true" required
                                   max="100"
                                   id="slug" value="<?php echo e(old('slug')); ?>"/>
                        </div>
                        <!-- Tags Form Input -->
                        <div class="form-group">
                            <label for="tags">Tags</label>
                            <select class="js-select-multiple form-control" name="tags[]" multiple="multiple" id="tags">
                                <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option value="">No tag available</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="input-field">
                            <label for="image">Feature Image</label>
                            <input type="file" name="post_img" id="image" value="<?php echo e(old('post_img')); ?>">
                        </div>
                        <div class="input-field">
                            <label for="post_desc">Post body</label>
                            <textarea name="details" rows="20" placeholder="Compose your masterpiece"
                                      aria-required="true"
                                      id="post_desc" style="height: auto;"><?php echo e(old('details')); ?></textarea>
                        </div>

                        <p class="form-submit">
                            <input type="submit" class="submit" value="Submit your post" required/>
                        </p>
                    </form>
                </div>
                <!-- #respond -->
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script defer src="<?php echo e(asset('js/tinymce/tinymce.min.js')); ?>">
    </script>
    <script async src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script>
        // Select2 int
        $(document).ready(function () {
            $('.js-select-multiple').select2();

            // TinyMCE
            tinymce.init({
                selector: 'textarea#post_desc',
                menubar: false,
                plugins: 'link code advlist lists table autosave anchor autolink emoticons media image imagetools preview print wordcount codesample',
                toolbar: 'styleselect formatting forecolor backcolor align| link image media | numlist bullist emoticons table preview print codesample code',
                codesample_languages: [
                    {text: 'HTML/XML', value: 'markup'},
                    {text: "XML", value: "xml"},
                    {text: "HTML", value: "html"},
                    {text: "SVG", value: "svg"},
                    {text: "CSS", value: "css"},
                    {text: "Javascript", value: "javascript"},
                    {text: "git", value: "git"},
                    {text: "java", value: "java"},
                    {text: "JSON", value: "json"},
                    {text: "less", value: "less"},
                    {text: "markdown", value: "markdown"},
                    {text: "PHP", value: "php"},
                    {text: "python", value: "python"},
                    {text: "sass", value: "sass"},
                    {text: "scss", value: "scss"},
                    {text: "SQL", value: "sql"},
                ],
                codesample_global_prismjs: true,
                toolbar_groups: {
                    formatting: {
                        icon: 'bold',
                        tooltip: 'Formatting',
                        items: 'bold italic underline | superscript subscript'
                    }
                },
                branding: false,
                height: 500
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\modernblog\resources\views/post/write.blade.php ENDPATH**/ ?>