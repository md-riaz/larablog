<?php $__env->startSection('title' ,'Add Category'); ?>

<?php $__env->startSection('content'); ?>

    <div class="col px-0 py-5">
        <div class="write-post">
            <div class="post-comments">
                <h2 class="comments-title">Add a new category here.</h2>
                <div class="comment-respond">
                    <form action="<?php echo e(route('category.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="d_flex">
                            <div class="input-field" style="width:100%">
                                <input type="text" name="name" placeholder="Category Name *" aria-required="true"/>
                            </div>

                        </div>

                        
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        

                        <p class="form-submit">
                            <input type="submit" class="submit" value="Add Category" required/>
                        </p>
                    </form>
                </div>
                <!-- #respond -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\modernblog\resources\views/category/store.blade.php ENDPATH**/ ?>