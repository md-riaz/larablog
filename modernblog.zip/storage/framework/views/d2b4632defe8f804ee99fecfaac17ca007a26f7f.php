<?php $__env->startSection('title' ,'Roles & Permissions'); ?>
<?php $__env->startSection('stylesheet'); ?>
    <!-- multiple-select minified CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/multiple-select.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .ms-drop input[type="checkbox"] {
            width: auto;
        }
    </style>
    <div class="jumbotron bg-light">
        <div class="float-right">
            <button class="btn text-primary" type="button">
                <a
                    href="#" class="btn create-role"
                    data-toggle="modal" data-target="#create-role">
                    <i class="fas fa-plus-circle"></i> Create Role
                </a>
            </button>
        </div>
        <h3 class="clearfix">Roles</h3>
        <div class="row">
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e($role->name); ?>

                        </div>
                        <div class="card-footer">
                            <button class="btn text-primary" type="button">
                                <a href="<?php echo e(route('roles.edit', $role->id)); ?>"><i class="far fa-edit"></i> Edit</a>
                            </button>

                            <button class="btn text-secondary" type="button">
                                <a href="<?php echo e(route('roles.show', $role->id)); ?>"><i class="far fa-eye"></i> Details</a>
                            </button>

                            <button class="btn text-danger" id="delete"
                                    data-action="<?php echo e(route('roles.destroy',$role->id)); ?>"><i
                                    class="fas fa-trash"></i> Delete
                            </button>

                            <form action="" id="deleteForm" method="POST" style="display: none">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                            </form>
                        </div>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <hr>
        <div class="float-right">
            <button class="btn text-primary" type="button">
                <a
                    href="#" class="btn create-permission"
                    data-toggle="modal" data-target="#create-permission">
                    <i class="fas fa-plus-circle"></i> Create Permission
                </a>
            </button>
        </div>
        <h3 class="clearfix">Permissions</h3>
        <div class="row">
            <div class="col-md-12">
                <!-- Data Table -->
                <div class="table-responsive text-nowrap">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Display Name</th>
                            <th>Slug</th>
                            <th>Description</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php echo e($loop->index+1); ?>

                                </td>
                                <td>
                                    <a href="#"><?php echo e(Str::limit($permission->display_name, 25)); ?></a>
                                </td>
                                <td>
                                    <?php echo e($permission->slug); ?>

                                </td>
                                <td>
                                    <?php echo e(Str::limit($permission->description, 30)); ?>

                                </td>

                                <td>
                                    <a href="<?php echo e(route('permissions.edit', $permission->id)); ?>"
                                       class="btn table-primary"><i
                                            class="far fa-edit"></i></a>

                                    <form action="#" id="deleteForm"
                                          method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn text-danger" id="delete"
                                                data-action="<?php echo e(route('permissions.destroy', $permission->id)); ?>"><i
                                                class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10">No data to show</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                    <!-- Data Table End -->

                </div>

            </div>

        </div>
    </div>


    <!-- Modal for role creating -->
    <div class="modal fade" id="create-role" tabindex="-1" role="dialog" aria-labelledby="create-role"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="<?php echo e(route('roles.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Create a Role</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <!-- Name Form Input -->
                        <div class="form-group">
                            <label for="name">Role Name</label>
                            <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name')); ?>"
                                   required>

                            <!-- Error display -->
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <!-- Error display End-->

                        </div><!-- Name Form Input End -->


                        <!-- Permissions Form Input -->
                        <div class="form-group">
                            <label for="permissions">Permissions</label>
                            <select multiple="multiple"
                                    placeholder="Select permissions"
                                    data-display-delimiter=" | "
                                    data-show-clear="true" data-animate='slide'
                                    name="permissions[]">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($permission->id); ?>"><?php echo e($permission->display_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div><!-- Permissions Form Input End -->
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn bg-sienna">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal for role creating -->
    <div class="modal fade" id="create-permission" tabindex="-1" role="dialog" aria-labelledby="create-permission"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="<?php echo e(route('permissions.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Create a Permission</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <!-- display_name Form Input -->
                        <div class="form-group">
                            <label for="display_name">Permission Name</label>
                            <input type="text"
                                   name="display_name"
                                   id="display_name"
                                   class="form-control"
                                   value="<?php echo e(old('display_name')); ?>"
                                   placeholder="Enter name"
                                   required>

                            <!-- Error display -->
                            <?php $__errorArgs = ['display_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <!-- Error display End-->

                        </div><!-- display_name Form Input End -->


                        <!-- Description Form Input -->
                        <div class="form-group">
                            <label for="description">Description</label>
                            <input type="text" name="description" id="description" class="form-control"
                                   placeholder="Enter Description" required>

                            <!-- Error display -->
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <!-- Error display End-->
                        </div><!-- Description Form Input End -->

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn bg-sienna">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/multiple-select.min.js')); ?>"></script>
    <script>
        $(function () {
            // initiate select2
            let select = $('select')
            select.multipleSelect({
                minimumCountSelected: 4
            })


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\modernblog\resources\views/roles/index.blade.php ENDPATH**/ ?>