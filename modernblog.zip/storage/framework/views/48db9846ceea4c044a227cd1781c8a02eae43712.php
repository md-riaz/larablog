<?php $__env->startSection('title' ,'Tags'); ?>

<?php $__env->startSection('content'); ?>

    <div class="col">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Tag::class)): ?>
            <div class="row write-tag">
                <div class="post-comments col-12">
                    <h2 class="comments-title">Add a new tag here.</h2>
                    <div class="comment-respond">
                        <form action="<?php echo e(route('tag.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="d_flex">
                                <div class="input-field" style="width:100%">
                                    <input type="text" name="name" placeholder="Tag Name *" aria-required="true"/>
                                </div>

                            </div>

                            
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            

                            <p class="form-submit">
                                <input type="submit" class="submit" value="Add Tag" required/>
                            </p>
                        </form>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\User::class)): ?>
            <div class="row mt-5">
                <div class="col-12">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Tags</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($tag->id); ?></td>
                                <td><a href="<?php echo e(route('tag.show', $tag->id)); ?>"><?php echo e($tag->name); ?></a></td>
                                <td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $tag)): ?>
                                        <a href="<?php echo e(route('tag.edit',$tag->id)); ?>" class="btn table-primary"><i
                                                class="far fa-edit"></i></a>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $tag)): ?>
                                        <form action="" id="deleteForm" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn text-danger" id="delete"
                                                    data-action="<?php echo e(route('tag.destroy',$tag->id)); ?>"><i
                                                    class="fas fa-trash"></i></button>
                                        </form>
                                    <?php endif; ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                    <!-- pagination -->
                <?php if($tags->lastPage() > 1): ?>
                    <?php echo e($tags->links()); ?>

                <?php endif; ?>
                <!-- pagination End -->
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\modernblog\resources\views/tags/store.blade.php ENDPATH**/ ?>