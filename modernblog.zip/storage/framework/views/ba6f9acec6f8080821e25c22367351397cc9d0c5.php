<!-- Header -->
<header class="header">
    <div class="header_inside d_flex">
        <div class="navigation-container">
            <!-- Mobile burger menu icon -->
            <div class="menuBar"><i class="fas fa-bars"></i></div>
            <div class="main-nav">
                <!-- navigation bar -->
                <nav>
                    <!-- mobile menu close btn -->
                    <div class="close"><i class="fas fa-times"></i></div>
                    <!-- menu start -->
                    <ul class="menu">
                        <li><a href="<?php echo e(URL::to('/')); ?>">home</a></li>
                        <li class="multi-nav"><a href="#">categories</a>
                            <ul class="sub-menu">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="menu-item"><a
                                            href="<?php echo e(url('/categories/'.$category->slug)); ?>"><?php echo e($category->name); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <li><a href="<?php echo e(route('contact.index')); ?>">contact</a></li>

                        <?php if(Route::has('login')): ?>
                            <?php if(auth()->guard()->check()): ?>

                            <?php else: ?>
                                <li>
                                    <a href="<?php echo e(route('login')); ?>">Login</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('register')); ?>">register</a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>

                    </ul>
                    <!-- menu end -->
                </nav>
            </div>
        </div>

    <?php if(auth()->check()): ?>
        <!-- if login, then show profile menus -->
            <div class="profile_menu">
                <div class="dropdown">
                    <span class="dropdown-toggle" type="button" id="dropdownMenuButton"
                          data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Hey! <?php echo e(auth()->user()->name); ?>

                    </span>
                    <div class="dropdown-menu shadow" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="<?php echo e(route('users.edit',auth()->id())); ?>"><i
                                class="far fa-user-circle"></i> profile</a>
                        <a class="dropdown-item" href="<?php echo e(route('post.create')); ?>"><i class="fas fa-pen-nib"></i> write
                            post</a>
                        <a class="dropdown-item" href="<?php echo e(route('category.index')); ?>"><i class="far fa-list-alt"></i>
                            categories</a>
                        <a class="dropdown-item" href="<?php echo e(route('tag.index')); ?>"><i class="fas fa-tags"></i> Tags</a>
                        <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>"><i class="fas fa-users"></i>
                            registered users</a>
                        <a class="dropdown-item" href="<?php echo e(route('post.index')); ?>"><i class="far fa-newspaper"></i> all
                            posts</a>
                        <a class="dropdown-item" href="<?php echo e(route('roles.index')); ?>"><i class="fas fa-user-shield"></i>
                            Roles & permissions</a>
                        <a class="dropdown-item" href="<?php echo e(route('users.setting')); ?>"><i class="fas fa-cog"></i>
                            Settings</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                            <i class="fas fa-sign-out-alt"></i>
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                              style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
            </div>
    <?php else: ?>
        <!-- if not logged then show social icons -->
            <div class="social_btns">
                <div class="social_btn">
                    <i class="fas fa-share-alt"></i>
                </div>

                <div class="social">
                    <a href="https://twitter.com/MDRiaz53949149"><i class="fab fa-twitter"></i></a>
                    <a href="http://www.facebook.com/mdriaz.wd"><i
                            class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a href="https://www.instagram.com/md_riaz___/"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-google-plus-g"></i></a>
                </div>
            </div>
        <?php endif; ?>


    </div>
    <!-- Main Logo -->
    <div class="logo-container bottom_bar">
        <a href="<?php echo e(URL::to('/')); ?>">Lara Blog</a>
    </div>
</header>
<!--   Header Section End -->
<?php /**PATH D:\laragon\www\modernblog\resources\views/components/header.blade.php ENDPATH**/ ?>