<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
<?php echo $__env->yieldContent('stylesheet'); ?>
<!--    head files   -->
    <?php echo $__env->make('partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
<div id="page-contianer">
    <!--    header component   -->
     <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <main id="main-content">
        <!-- feature post component -->
        <?php if(Request::is('/')): ?>
             <?php if (isset($component)) { $__componentOriginal97f6b4fb35ffe6b36cf32715e64e93fb41b427da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Featured::class, []); ?>
<?php $component->withName('featured'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal97f6b4fb35ffe6b36cf32715e64e93fb41b427da)): ?>
<?php $component = $__componentOriginal97f6b4fb35ffe6b36cf32715e64e93fb41b427da; ?>
<?php unset($__componentOriginal97f6b4fb35ffe6b36cf32715e64e93fb41b427da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php endif; ?>


        <section class="Contents py-5">
            <div class="container">
                <?php echo $__env->yieldContent('content'); ?>


            </div>
        </section>
    </main>

</div>
<!--    all scripts   -->
<?php echo $__env->make('partials._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('scripts'); ?>

</body>

</html>
<?php /**PATH D:\laragon\www\modernblog\resources\views/layouts/manage.blade.php ENDPATH**/ ?>