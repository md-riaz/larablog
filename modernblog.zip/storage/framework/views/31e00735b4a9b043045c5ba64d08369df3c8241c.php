<?php $__env->startSection('title', 'Edit Post'); ?>
<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="col p-0 pb-5">
        <div class="write-post">
            <div class="post-comments">
                <h2 class="comments-title">Edit an existing post.</h2>
                <div class="comment-respond">
                    <form action="<?php echo e(route('post.edit', $post->id)); ?>" method="post"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="d_flex justify-between">
                            <div class="input-field">
                                <label for="title">Title</label>
                                <input type="text" name="title" value="<?php echo e($post->title); ?>"
                                       aria-required="true" required
                                       id="title" max="255"/>
                            </div>
                            <div class="input-field">
                                <label for="category">Category</label>
                                <select name="category_id" id="category">
                                    <option value="" disabled>Select a Category</option>
                                    <?php $__currentLoopData = $categories;
                                    $__env->addLoop($__currentLoopData);
                                    foreach ($__currentLoopData as $item): $__env->incrementLoopIndices();
                                        $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($item->id); ?>" <?php echo e($item->id == $post->category_id ? 'selected' : ''); ?>>
                                            <?php echo e($item->name); ?></option>
                                    <?php endforeach;
                                    $__env->popLoop();
                                    $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="input-field">
                            <label for="slug">Slug</label>
                            <input type="text" name="slug" placeholder="Slug/url*" aria-required="true" required
                                   max="100"
                                   id="slug" value="<?php echo e($post->slug); ?>"/>
                        </div>
                        <!-- Tags Form Input -->
                        <div class="form-group">
                            <label for="tags">Tags</label>
                            <select class="js-select-multiple form-control" name="tags[]" multiple="multiple">
                                <?php $__empty_1 = true;
                                $__currentLoopData = $tags;
                                $__env->addLoop($__currentLoopData);
                                foreach ($__currentLoopData as $tag): $__env->incrementLoopIndices();
                                    $loop = $__env->getLastLoop();
                                    $__empty_1 = false; ?>
                                    <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                                <?php endforeach;
                                $__env->popLoop();
                                $loop = $__env->getLastLoop();
                                if ($__empty_1): ?>
                                    <option value="">No tag available</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="input-field">
                            <label for="image">Feature Image</label>
                            <input type="file" name="post_img" id="image">
                            <label for="">Current Image</label><br>
                            <img data-src="<?php echo e(asset($post->post_img)); ?>" class="lazyload" loading="lazy"
                                 alt="old img"
                                 width="300">
                        </div>
                        <div class=" input-field">
                            <label for="post_desc">Post body</label>
                            <textarea name="details" rows="20" id="post_desc" style="height: auto;" aria-required="true"
                                      required><?php echo e($post->details); ?></textarea>
                        </div>


                        <?php if ($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all();
                                    $__env->addLoop($__currentLoopData);
                                    foreach ($__currentLoopData as $error): $__env->incrementLoopIndices();
                                        $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach;
                                    $__env->popLoop();
                                    $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>


                        <p class="form-submit">
                            <input type="submit" class="submit" value="Update Post" required/>
                        </p>
                    </form>
                </div>
                <!-- #respond -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.tiny.cloud/1/g4v6bvbx4urk83696i0550n97p3pmdnlda80zmyq6f88iu4w/tinymce/5/tinymce.min.js">
    </script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script>
        // Select2 int
        $(document).ready(function () {
            $('.js-select-multiple').select2();
            var tags = []; // declare an empty array
            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> // loop through each tags
            tags["<?php echo e($tag->id); ?>"] = "<?php echo e($tag->id); ?>"; // convert all tag id's into an associative array
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            $('.js-select-multiple').select2().val(tags).trigger('change'); // Notify any JS components that the value changed


            // TinyMCE
            tinymce.init({
                selector: 'textarea#post_desc',
                menubar: false,
                plugins: 'link code advlist lists table autosave anchor autolink emoticons media image imagetools preview print wordcount codesample',
                toolbar: 'styleselect formatting forecolor backcolor align| link image media | numlist bullist emoticons table preview print codesample code',
                codesample_languages: [
                    {text: 'HTML/XML', value: 'markup'},
                    {text: "XML", value: "xml"},
                    {text: "HTML", value: "html"},
                    {text: "SVG", value: "svg"},
                    {text: "CSS", value: "css"},
                    {text: "Javascript", value: "javascript"},
                    {text: "git", value: "git"},
                    {text: "java", value: "java"},
                    {text: "JSON", value: "json"},
                    {text: "less", value: "less"},
                    {text: "markdown", value: "markdown"},
                    {text: "PHP", value: "php"},
                    {text: "python", value: "python"},
                    {text: "sass", value: "sass"},
                    {text: "scss", value: "scss"},
                    {text: "SQL", value: "sql"},
                ],
                codesample_global_prismjs: true,
                toolbar_groups: {
                    formatting: {
                        icon: 'bold',
                        tooltip: 'Formatting',
                        items: 'bold italic underline | superscript subscript'
                    }
                },
                branding: false,
                height: 500
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\modernblog\resources\views/post/edit.blade.php ENDPATH**/ ?>
