<?php $__env->startSection('title' ,'All Category'); ?>

<?php $__env->startSection('content'); ?>

    <div class="col p-0">
        <div class="d-flex justify-content-between mb-3">
            <h3 class="mb-0">All Categories</h3>
            <a href="<?php echo e(route('category.create')); ?>" class="btn bg-sienna text-white">ADD+</a>
        </div>
        <div class="table-responsive text-nowrap">
            <table class="table table-striped">
                <thead>
                <th>SL</th>
                <th>Category Name</th>
                <th>Slug</th>
                <th>Author</th>
                <th>Created at</th>
                <th>Action</th>
                </thead>
                <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($categories->firstItem() + $loop->index); ?></td>
                        <td><?php echo e($row->name); ?></td>
                        <td><?php echo e($row->slug); ?></td>
                        <td><?php echo e($row->user->name); ?></td>
                        <td><?php echo e($row->created_at->format('dS F, Y')); ?></td>
                        <td>
                            <a href="<?php echo e(route('category.edit', $row->id)); ?>" class="btn text-primary"><i
                                    class="far fa-edit"></i></a>
                            <a href="<?php echo e(route('category.show',$row->id)); ?>" class="btn text-secondary"><i
                                    class="far fa-eye"></i></a>

                            <form action="" id="deleteForm" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn text-danger" id="delete"
                                        data-action="<?php echo e(route('category.destroy',$row->id)); ?>"><i
                                        class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <!-- pagination -->
        <?php if($categories->lastPage() > 1): ?>
            <?php echo e($categories->links()); ?>

        <?php endif; ?>
        <!-- pagination End -->

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\modernblog\resources\views/category/allcategory.blade.php ENDPATH**/ ?>