<?php $__env->startSection('title' ,'All Posts'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col p-0">

        <!-- Table title -->
        <div class="d-flex justify-content-between mb-3">
            <h3 class="mb-0">Posted by author's</h3>
            <a href="<?php echo e(route('post.create')); ?>" class="btn bg-sienna text-white">Write</a>
        </div>
        <!-- Table title End -->

        <!-- Data Table -->
        <div class="table-responsive text-nowrap">
            <table class="table table--striped ">
                <thead>
                <th>SL</th>
                <th>Post Title</th>
                <th>Author</th>
                <th>Category</th>
                <th>Image</th>
                <th>Action</th>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php echo e($posts->firstItem() + $loop->index); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(url('post/'. $row->slug)); ?>"><?php echo e(Str::limit($row->title, 25)); ?></a>
                        </td>
                        <td>
                            <a href="<?php echo e(url('user/'.$row->user->id.'/posts')); ?>"><?php echo e($row->user->name); ?></a>
                        </td>
                        <td>
                            <a href="<?php echo e(url('/categories/'.$row->category->slug)); ?>"><?php echo e($row->category->name); ?></a>
                        </td>
                        <td>
                            <img data-src="<?php echo e(asset($row->post_img)); ?>" class="lazyload" loading="lazy" alt="post thumb"
                                 width="80" height="50">
                        </td>
                        <td>
                            <a href="<?php echo e(route('post.edit',$row->id)); ?>" class="btn table-primary"><i
                                    class="far fa-edit"></i></a>

                            <form action="" id="deleteForm" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn text-danger" id="delete"
                                        data-action="<?php echo e(route('post.destroy',$row->id)); ?>"><i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10">No data to show</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
            <!-- Data Table End -->
            <!-- pagination -->
        <?php if($posts->lastPage() > 1): ?>
            <?php echo e($posts->links()); ?>

        <?php endif; ?>
        <!-- pagination End -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\modernblog\resources\views/post/all.blade.php ENDPATH**/ ?>