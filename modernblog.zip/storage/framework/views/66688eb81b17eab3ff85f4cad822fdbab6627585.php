<?php $__env->startSection('title' ,'larablog | A laravel blog'); ?>

<?php $__env->startSection('content'); ?>

    <!--   Main Post Section -->
    <section class="post-list">
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="posts">
                <div class="posts_contents_wrapper d_flex">
                    <div class="posts_preview_img">
                        <img data-src="<?php echo e(asset($post->thumbnail)); ?>" class="lazyload" loading="lazy" alt="preview_img"
                             width="400" height="250">
                    </div>
                    <div class="posts_desc d_flex">
                        <div class="posts_title">
                            <div class="categories d_flex">
                                <a href="<?php echo e(url('/categories/'.$post->category->slug)); ?>"><?php echo e($post->category->name); ?></a>
                            </div>
                            <a class="title" href="<?php echo e(url('post/'. $post->slug)); ?>">
                                <?php echo e($post->title); ?>

                            </a>
                            <div class="info d_flex">
                                <p class="date"><?php echo e($post->created_at->format('d F, Y')); ?></p>
                                <p class="author">by <a
                                        href="<?php echo e(url('user/'.$post->user->id.'/posts')); ?>"><?php echo e($post->user->name); ?></a></p>
                            </div>
                        </div>
                        <p class="text_contents">
                            <?php echo e(Str::limit(strip_tags($post->details), 300)); ?>

                            <br>
                            <a class="read_more" href="<?php echo e(url('post/'. $post->slug)); ?>">...</a>
                        </p>
                    </div>
                </div>
                <div class="post_buttons d_flex">
                    <div class="comments d_flex">
                        <a href="<?php echo e(url('post/'. $post->slug.'#comments')); ?>"> <i class="far fa-comment"></i>
                            <?php echo e($post->comments->count()); ?></a>
                    </div>
                    <div class="post_share">
                        <span>Share</span>
                        <a href="http://www.facebook.com/sharer.php?u=<?php echo e(URL::current()); ?>&t=<?php echo e($post->title); ?>"><i
                                class="fab fa-facebook-f"></i></a>
                        <a href="https://twitter.com/intent/tweet?url=<?php echo e(URL::current()); ?>&text=<?php echo e($post->title); ?>"><i
                                class="fab fa-twitter"></i></a>
                        <a href="#" onclick="event.preventDefault();copyToClipboard('<?php echo e(url('post/'. $post->slug)); ?>');"
                           id="copy"><i class="far fa-clipboard"></i></a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-center">No articles to show</p>
    <?php endif; ?>

    <!-- pagination -->
    <?php if($posts->lastPage() > 1): ?>
        <?php echo e($posts->links()); ?>

    <?php endif; ?>
    <!-- pagination End -->


    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\modernblog\resources\views/index.blade.php ENDPATH**/ ?>