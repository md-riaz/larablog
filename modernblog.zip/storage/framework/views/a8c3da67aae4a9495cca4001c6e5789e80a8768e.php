<?php $__env->startSection('title' ,'Edit Role'); ?>
<?php $__env->startSection('stylesheet'); ?>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/multiple-select.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .ms-drop input[type="checkbox"] {
            width: auto;
        }
    </style>
    <div class="row">
        <div class="col-md-8 m-auto">
            <div class="card">
                <div class="card-header bg-sienna">
                    Edit this Role
                </div>
                <div class="card-footer">
                    <form action="<?php echo e(route('roles.update', $role->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <!-- Name Form Input -->
                        <div class="form-group">
                            <label for="name">Role Name</label>
                            <input type="text" name="name" id="name" class="form-control" value="<?php echo e($role->name); ?>"
                                   required>

                        </div><!-- Name Form Input End -->


                        <!-- Permissions Form Input -->
                        <div class="form-group">
                            <label for="permissions">Permissions</label>
                            <select multiple="multiple"
                                    data-display-delimiter=" | "
                                    data-show-clear="true" data-animate='slide'
                                    name="permissions[]">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($permission->id); ?>"><?php echo e($permission->display_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div><!-- Permissions Form Input End -->

                        <button type="submit" class="btn bg-sienna">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <!-- Latest compiled and minified JavaScript -->
    <script src="<?php echo e(asset('js/multiple-select.min.js')); ?>"></script>
    <script>
        $(function () {
            let select = $('select')
            select.multipleSelect({
                minimumCountSelected: 6
            })

            let permissions = []
            <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            permissions.push(<?php echo e($permission->id); ?>)
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            select.multipleSelect('setSelects', permissions)
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\modernblog\resources\views/roles/edit.blade.php ENDPATH**/ ?>