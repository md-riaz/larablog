<!--   Side Bar -->
<section class="side-content">
    <div class="about_me">
        <div class="about_me_inner d_flex">
            <div class="avtar">
                <img data-src="<?php echo e(asset('images/me.webp')); ?>" class="lazyload" loading="lazy" alt="my_avtar" width="170"
                     height="234">
            </div>
            <div class="title">about me</div>
            <p class="texts">Hi! My name is
                <b>MD Riaz</b>. This is my blog site. It is based on laravel framework. </p>
            <div class="follow_buttons">
                <p class="follow">follow me on
                </p>
                <div class="social">
                    <a href="https://twitter.com/MDRiaz53949149"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.facebook.com/mdriaz.wd"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a href="https://www.instagram.com/md_riaz__"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-google-plus-g"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="subscribe">
        <h3 class="bottom_bar">newshelter</h3>
        <form action="<?php echo e(route('subscribe')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="email" name="email" id="email" placeholder="your email address">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button type="submit" class="flat-btn">subscribe</button>
        </form>
    </div>
    <div class="follow_insta">
        <h3 class="bottom_bar">follow@md_riaz___</h3>
        <div class="photo_grid d_flex">
            <img data-src="<?php echo e(asset('images/photo_grid/1.webp')); ?>" class="lazyload" loading="lazy" alt="grid_image"
                 width="87" height="87">
            <img data-src="<?php echo e(asset('images/photo_grid/2.webp')); ?>" class="lazyload" loading="lazy" alt="grid_image"
                 width="87" height="87">
            <img data-src="<?php echo e(asset('images/photo_grid/4.webp')); ?>" class="lazyload" loading="lazy" alt="grid_image"
                 width="87" height="87">
            <img data-src="<?php echo e(asset('images/photo_grid/5.webp')); ?>" class="lazyload" loading="lazy" alt="grid_image"
                 width="87" height="87">
            <img data-src="<?php echo e(asset('images/photo_grid/3.webp')); ?>" class="lazyload" loading="lazy" alt="grid_image"
                 width="87" height="87">
            <img data-src="<?php echo e(asset('images/photo_grid/6.webp')); ?>" class="lazyload" loading="lazy" alt="grid_image"
                 width="87" height="87">
            <img data-src="<?php echo e(asset('images/photo_grid/7.webp')); ?>" class="lazyload" loading="lazy" alt="grid_image"
                 width="87" height="87">
            <img data-src="<?php echo e(asset('images/photo_grid/8.webp')); ?>" class="lazyload" loading="lazy" alt="grid_image"
                 width="87" height="87">
            <img data-src="<?php echo e(asset('images/photo_grid/9.webp')); ?>" class="lazyload" loading="lazy" alt="grid_image"
                 width="87" height="87">
        </div>
    </div>
    <div class="category_section">
        <h3 class="bottom_bar">categories</h3>
        <ul>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="menu-item"><a href="<?php echo e(url('/categories/'.$category->slug)); ?>"><?php echo e($category->name); ?></a>
                    <span><?php echo e($category->posts_count); ?></span></li> <!-- count how many post in a category -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="latest_posts">
        <h3 class="bottom_bar">recent posts</h3>

        <div class="latest_post_wrapper">
            <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="latest_post d_flex">
                    <div class="latest_post_preview_img">
                        <img data-src="<?php echo e(asset($item->thumbnail)); ?>" class="lazyload" loading="lazy" alt="preview_img"
                             width="70" height="70">
                    </div>
                    <div class="posts_desc">
                        <p class="date"><?php echo e($item->created_at->format('d F, Y')); ?></p>
                        <a href="<?php echo e(url('post/'.$item->slug)); ?>">
                            <h3 class="title"><?php echo e($item->title); ?></h3>
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

    <div class="search_bar">
        <form action="<?php echo e(route('searchItem')); ?>" method="get" id="searchForm" class="d_flex">
            <?php echo csrf_field(); ?>
            <input type="text" name="search" id="search" placeholder="search...">
            <button class="flat-btn"><i class="fas fa-search"></i></button>
        </form>
        <span class="searchlist"></span>
    </div>

    <div class="banner">
        <h3 class="bottom_bar">banner</h3>
        <div class="banner_img">
            <img data-src="<?php echo e(asset('images/banner.webp')); ?>" class="lazyload" loading="lazy" alt="banner_img"
                 width="270" height="368">
        </div>
    </div>

    <div class="follow_fb">
        <h3 class="bottom_bar">find us on Facebook</h3>
        <div class="fb_frame">

        </div>
    </div>

    <!-- Tags Section -->
    <div class="tags">
        <h3 class="bottom_bar">tags</h3>
        <ul class="taglist d_flex">
            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url('/')); ?>?tag=<?php echo e($tag->name); ?>"><?php echo e($tag->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <!-- Tags Section End -->
</section>
<?php $__env->startSection('scripts'); ?>
    <script>
        /* select all needed items */
        var searchInput = $('#search'),
            searchForm = $('#searchForm'),
            action = searchForm.attr('action'),
            method = searchForm.attr('method'),
            searchlist = $('.searchlist')

        /* On search input, check empty or make ajax req */
        searchInput.on('keyup', () => {
            // empty the list
            searchlist.html("")
            if (searchInput.val() === "") {
                searchlist.fadeOut("slow")
            } else {
                // or make ajax get req
                searchlist.fadeIn("slow")
                $.ajax({
                    url: action,
                    type: method,
                    data: {'search': searchInput.val()},
                    success: (data) => {
                        // loop array & make url
                        $.each(data, function (slug, title) {
                            searchlist.append(`<a href=post/${slug}>${title}</a><hr>`)
                        });
                    },
                    // if error found show something
                    error: () => {
                        searchlist.html("Nothing Found")
                    }
                })
            }

        })
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\laragon\www\modernblog\resources\views/components/sidebar.blade.php ENDPATH**/ ?>