<?php $__env->startSection('title'); ?>
<?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="post-list">
        <div class="posts">
            <div class="posts_contents_wrapper d_flex">
                <div class="post_details d_flex">
                    <div class="posts_title">
                        <div class="categories d_flex">
                            <a href="<?php echo e(url('/categories/' . $post->category->slug)); ?>"><?php echo e($post->category->name); ?></a>
                        </div>
                        <a class="title">
                            <?php echo e($post->title); ?>

                        </a>
                        <div class="info d_flex">
                            <p class="date"><?php echo e($post->created_at->format('jS F, Y')); ?></p>
                            <p class="author">by <a
                                        href="<?php echo e(url('user/' . $post->user->id . '/posts')); ?>"><?php echo e($post->user->name); ?></a>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="post_img">
                    <img data-src="<?php echo e(asset($post->post_img)); ?>"
                         src="<?php echo e(asset($post->post_img)); ?>" class="lazyload"
                         loading="lazy" alt="preview_img" width="800"/>
                </div>
                <div class="entry-content">

                    <?php echo $post->details; ?>


                </div>
                <div class="tags">
                    <ul class="taglist d_flex">
                        <?php $__currentLoopData = $post->tags;
                        $__env->addLoop($__currentLoopData);
                        foreach ($__currentLoopData as $tag): $__env->incrementLoopIndices();
                            $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(url('/')); ?>?tag=<?php echo e($tag->name); ?>"><?php echo e($tag->name); ?></a>
                            </li>
                        <?php endforeach;
                        $__env->popLoop();
                        $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

            </div>
            <div class="post_buttons d_flex details_page">
                <div class="post_share">
                    <span>Share</span>
                    <a href="http://www.facebook.com/sharer.php?u=<?php echo e(URL::current()); ?>&t=<?php echo e($post->title); ?>"><i
                                class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/intent/tweet?url=<?php echo e(URL::current()); ?>&text=<?php echo e($post->title); ?>"><i
                                class="fab fa-twitter"></i></a>
                    <a href="#"
                       onclick="event.stopPropagation();copyToClipboard('<?php echo e(url('post/' . $post->slug)); ?>');"
                       id="copy"><i class="far fa-clipboard"></i>
                    </a>
                </div>
            </div>
        </div>
        <nav class="post-navigation d_flex">
            <?php if (isset($previous)): ?>
                <div class="prev_post post_link">
                    <a href="<?php echo e(url('post/' . $previous->slug)); ?>" rel="prev">
                        <span class="meta-nav">Previous Post</span>
                        <div class="post-content">
                    <span class="title">
                        <?php echo e($previous->title); ?>

                    </span>
                        </div>
                    </a>
                </div>
            <?php endif; ?>
            <?php if (isset($next)): ?>
                <div class="next-post post_link">
                    <a href="<?php echo e(url('post/' . $next->slug)); ?>" rel="prev">
                        <span class="meta-nav">Next Post</span>
                        <div class="post-content">
                            <span class="title"><?php echo e($next->title); ?></span>
                        </div>
                    </a>
                </div>
            <?php endif; ?>

        </nav>
        <div class="post-comments" id="comments">
            <h2 class="comments-title"><?php echo e($post->comments->count()); ?> Comments</h2>
            <div class="comment-section">
                <?php $__empty_1 = true;
                $__currentLoopData = $post->comments;
                $__env->addLoop($__currentLoopData);
                foreach ($__currentLoopData as $comment): $__env->incrementLoopIndices();
                    $loop = $__env->getLastLoop();
                    $__empty_1 = false; ?>
                    <div class="single-comment d-flex pt-2 pb-2">
                        <div class="single-comment__avater mr-3"
                             style="background-image: url(<?php echo e($comment->avatar); ?>)">
                        </div>
                        <div class="single-comment__content">
                            <div class="single-comment--name font-weight-bold">
                                <?php echo e($comment->name); ?>

                                <small class="float-right"><?php echo e($comment->created_at->diffForHumans()); ?></small>
                                <small class="d-block text-black-50"><?php echo e($comment->email); ?></small>
                            </div>

                            <div class="single-comment--message">
                                <?php echo e($comment->comment); ?>

                            </div>
                            <?php if (auth()->guard()->check()): ?>
                                <form action="" method="post" id="deleteForm">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn text-danger" id="delete"
                                            data-action="<?php echo e(route('comment.destroy', $comment->id)); ?>"><i
                                                class="fas fa-trash"></i></button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach;
                $__env->popLoop();
                $loop = $__env->getLastLoop();
                if ($__empty_1): ?>

                <?php endif; ?>

            </div>

            <div class="comment-respond">
                <h2 class="comment-reply-title">
                    Leave a comment
                </h2>
                <form action="<?php echo e(route('comment.store/', $post->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <p class="comment-notes">
                        Your email address will not be published.
                    </p>

                    <div class="input-field">
                        <textarea name="comment" placeholder="Your Comment *" aria-required="true"></textarea>
                    </div>

                    <div class="d_flex justify-between">
                        <div class="input-field">
                            <input type="text" name="name" placeholder="Name *" aria-required="true"/>
                        </div>
                        <div class="input-field">
                            <input type="email" name="email" placeholder="Email *" aria-required="true"/>
                        </div>
                    </div>
                    <p class="form-submit">
                        <input type="submit" class="submit" value="Post Your Comment"/>
                    </p>
                </form>
            </div>
            <!-- #respond -->
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\modernblog\resources\views/post/show.blade.php ENDPATH**/ ?>
