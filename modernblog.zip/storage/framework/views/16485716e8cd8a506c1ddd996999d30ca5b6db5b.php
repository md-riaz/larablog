<?php $__env->startSection('title' ,'Role Details'); ?>
<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="jumbotron bg-light">
        <div class="float-right">
            <button class="btn text-primary" type="button">
                <a href="<?php echo e(route('roles.edit', $role->id)); ?>"><i class="far fa-edit"></i> Edit</a>
            </button>
        </div>
        <h3>Role <?php echo e($role->name); ?></h3>
        <hr>
        <div class="row">
            <div class="col">
                <!-- Tags Form Input -->
                <div class="form-group">
                    <label for="tags">Permissions</label>
                    <select class="js-select-multiple form-control" name="permissions[]" multiple="multiple">
                        <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($permission->id); ?>"><?php echo e($permission->display_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option value="">No permission available</option>
                        <?php endif; ?>
                    </select>

                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script>
        // Select2 int
        $(document).ready(function () {
            $('.js-select-multiple').select2();
            var permissions = []; // declare an empty array
            <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> // loop through each permissions
            permissions.push(<?php echo e($permission->id); ?>) // push id to permission array
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            $('.js-select-multiple').select2().val(permissions).trigger('change'); // Notify any JS components that the value changed

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\modernblog\resources\views/roles/show.blade.php ENDPATH**/ ?>