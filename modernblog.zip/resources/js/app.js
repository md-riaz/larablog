require('./bootstrap');
require('./lazysizes.min');
require('./OwlCarousel2_2.3.4');
require('./prism');
require('./select2');
require('./main');
